﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MedicineStock.Models
{
    public class MedicineModel
    {
        [DisplayName("Medicine Brand Name")]
        [Required(ErrorMessage = "Brand Name is mandatory")]
        public string MedicineName { get; set; }

        [Required(ErrorMessage = "Price is required")]
        [RegularExpression(@"\d+(\.\d{1,2})?", ErrorMessage = "Invalid price")]
        public decimal Price { get; set; }

        [Required]
        public int Stock { get; set; }

        [Required]
        public int ShelveNumber { get; set; }

    }
}