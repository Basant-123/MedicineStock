create procedure sp_insertMedicine
@MedicineName as varchar(20),
@Quantity as varchar(20),
@ShelveNo as int,
@price as decimal

as
begin
Insert into Product Values(@MedicineName,@Quantity ,@ShelveNo,@price)
end