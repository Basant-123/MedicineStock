create procedure sp_getMedicine
as
begin

select * from Medicine

end
execute sp_getMedicine