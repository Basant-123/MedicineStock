﻿using MedicineStock.BuisnessEngine;
using MedicineStock.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MedicineStock.Controllers
{
    public class MedicineController : Controller
    {
        // GET: Medicine/Create
        [HttpGet]
        public ActionResult Create()
        {
            return View(new MedicineModel());
        }

        [HttpGet]
        public ActionResult Display()
        {
            MedicineBizEngine medicine = new MedicineBizEngine();
            return View(medicine.getMedicineData());
        }
        [HttpPost]
        public ActionResult Create(MedicineModel medicineModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    MedicineBizEngine medicineBiz = new MedicineBizEngine();


                    // TODO: Add insert logic here
                    medicineBiz.insertMedicineData(medicineModel);
                }
                catch (Exception ex)
                {
                    throw;
                }
                return RedirectToAction("Display");
            }
            else
            {
                return View("Error");
            }


        }

      
    }
}
