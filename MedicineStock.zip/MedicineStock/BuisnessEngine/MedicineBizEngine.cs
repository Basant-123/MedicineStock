﻿using MedicineStock.Common;
using MedicineStock.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MedicineStock.BuisnessEngine
{
    public class MedicineBizEngine
    {
        // Business layer
        public DataTable getMedicineData()
        {
            DataTable dtblproduct = new DataTable();
            SqlCommand cmd = new SqlCommand();

            DAL dal = DAL.getInstance();
            using (SqlConnection con = dal.GetConnection())
            {
               
                cmd = new SqlCommand("sp_getMedicine", con);
                cmd.CommandType = CommandType.StoredProcedure;             
                SqlDataAdapter sqlda = new SqlDataAdapter(cmd);
                sqlda.Fill(dtblproduct);
               
            }

            return dtblproduct;
        }
        public void insertMedicineData(MedicineModel medModel)
        {
            DAL dal = DAL.getInstance();
            try
            {
                using (SqlConnection con = dal.GetConnection())
                {
                    // string query = "Insert into Product Values(@ProductTitle,@ProductImage,@price,@Stock)";
                    SqlCommand sqlCmd = new SqlCommand("sp_insertMedicine", con);
                    sqlCmd.CommandType = CommandType.StoredProcedure;

                    sqlCmd.Parameters.AddWithValue("@MedicineName", medModel.MedicineName);
                    sqlCmd.Parameters.AddWithValue("@ShelveNo", medModel.ShelveNumber);
                    sqlCmd.Parameters.AddWithValue("@Price", medModel.Price);
                    sqlCmd.Parameters.AddWithValue("@Quantity", medModel.Stock);

                    sqlCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }
    }
}